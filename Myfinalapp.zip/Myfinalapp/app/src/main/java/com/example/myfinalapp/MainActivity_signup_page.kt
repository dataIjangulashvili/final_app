package com.example.myfinalapp

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity_signup_page : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_signup_page)

        val passwordEditText = findViewById<EditText>(R.id.input_password)
        val confirmPasswordEditText = findViewById<EditText>(R.id.repeat_password)
        val confirmButton = findViewById<Button>(R.id.Signup_pg_btn)

        confirmButton.setOnClickListener {
            val password = passwordEditText.text.toString()
            val confirmPassword = confirmPasswordEditText.text.toString()
            if (password != confirmPassword) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(this, MainActivity_profile_page::class.java)
                intent.putExtra("key", "string")
                startActivity(intent)
            }
        }
    }
}