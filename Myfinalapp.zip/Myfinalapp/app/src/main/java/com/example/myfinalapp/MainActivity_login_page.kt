package com.example.myfinalapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity_login_page : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_login_page)
    }
}